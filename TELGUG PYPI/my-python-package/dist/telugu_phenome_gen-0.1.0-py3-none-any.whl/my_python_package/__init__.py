# Contents of /my-python-package/my-python-package/src/my_python_package/__init__.py

from .phenome_gen import process_text, text_to_phonemes

__all__ = ['process_text', 'text_to_phonemes']